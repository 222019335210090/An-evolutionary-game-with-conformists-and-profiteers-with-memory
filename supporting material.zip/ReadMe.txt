The source code of our paper has 7 files, which correspond to the 7 figures in the simulation part of the paper. Besides, each file contains py type file and ipynb type file, which is suffixed with py is our main code, by running it can get the result data we want, and the data will be saved in json type to the saves file, and finally through the ipynb will get the results of the visualization, pdf file that is the simulation result.

Correspondence between the file and the figure of our paper:
File t_fc(c,r) corresponds to Figure 2;
File r_fc(c) corresponds to Figure 3;
File c_fc(r) corresponds to Figure 4;
File T_fc(c) corresponds to Figure 5;
File Snapshots corresponds to Figure 6;
File row_fc(c) corresponds to Figure 7;
File n_fc(c,r) corresponds to Figure 8.