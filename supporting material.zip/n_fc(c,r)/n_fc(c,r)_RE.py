import networkx as nx
import random
import matplotlib.pyplot as plt
import numpy as np
import json
import warnings

warnings.filterwarnings('ignore')

# Generate a regular network based on the number of network nodes
def regular_network(n):
    Graph = nx.Graph()
    for i in range(n):
        Graph.add_node(i)
    sqrt_n = int(np.sqrt(n))
    for i in range(sqrt_n):
        for j in range(sqrt_n - 1):
            Graph.add_edge(i * sqrt_n + j, i * sqrt_n + j + 1)
    for i in range(sqrt_n - 1):
        for j in range(sqrt_n):
            Graph.add_edge(i * sqrt_n + j, i * sqrt_n + j + sqrt_n)
    return Graph

nlist = [10 * 10, 15 * 15, 20 * 20, 25 * 25, 30 * 30, 35 * 35, 40 * 40]
ETime = 5000  # Evolutionary game steps
game = 'SG'
T = 5  # memory length
clist = [0.3, 0.3, 0.5]
rlist = [0.4, 0.6, 0.6]

fun_s = lambda x: random.uniform(0, 1) > x  # Get the strategy of the node according to s (False for cooperation, True for defection)
fun_f = lambda x: (len(x) - sum(list(map(lambda x: x[-1], list(x.values()))))) / len(x) # Calculate the fc based on the dictionary of strategy
result = {}

for k in range(3):
    c = clist[k]
    r = rlist[k]
    if game == "SG":
        pom = [[1, 1 - r], [1 + r, 0]]
    for num in range(len(nlist)):
        n = nlist[num]
        G = regular_network(n)

        Strategy = {}
        Cooperate_degree = {}
        f_c = []
        Type = []

        for i in G.nodes:
            Type.append(0 <= random.uniform(0, 1) < 0.5)  # False for profiteer, True for conformist
            Cooperate_degree[i] = [random.uniform(0, 1)]
            Strategy[i] = [fun_s(Cooperate_degree[i][-1])]
        f_c.append(fun_f(Strategy))
        # iteration
        for t in range(ETime):
            print("\rn={:.0f},c={:.1f},r={:.1f},t={:.0f},fc={:.3f}".format(n, c, r, t, f_c[t]), end='')
            for x in range(0, n):
                x_nei = list(G.neighbors(x))
                Ux = 0
                for i in x_nei:
                    if Strategy[x][t] == Strategy[i][t] == False:  # C-C
                        Ux += Cooperate_degree[x][t] * Cooperate_degree[i][t] * pom[Strategy[x][t]][Strategy[i][t]]
                    elif (Strategy[x][t] == True) and (Strategy[i][t] == False):  # D-C
                        Ux += (1 - Cooperate_degree[x][t]) * Cooperate_degree[i][t] * pom[Strategy[x][t]][Strategy[i][t]]
                    else:
                        Ux += pom[Strategy[x][t]][Strategy[i][t]]

                y = random.choice(x_nei)  # randomly choose a neighbor
                y_nei = list(G.neighbors(y))
                Uy = 0
                for i in y_nei:
                    if Strategy[y][t] == Strategy[i][t] == False:  # C-C
                        Uy += Cooperate_degree[y][t] * Cooperate_degree[i][t] * pom[Strategy[y][t]][Strategy[i][t]]
                    elif (Strategy[y][t] == True) and (Strategy[i][t] == False):  # D-C
                        Uy += (1 - Cooperate_degree[y][t]) * Cooperate_degree[i][t] * pom[Strategy[y][t]][Strategy[i][t]]
                    else:
                        Uy += pom[Strategy[y][t]][Strategy[i][t]]

                if Type[x] == False:  # x is a profiteer
                    s_change = Strategy[y][t]
                    if s_change == False:  # the target is a cooperator
                        memory = (len(Strategy[x][-T:]) - sum(Strategy[x][-T:])) / len(Strategy[x][-T:])
                    else:  # the target is a defector
                        memory = sum(Strategy[x][-T:]) / len(Strategy[x][-T:])
                    ran = c * memory + (1 - c) * (1 / (1 + np.exp((Ux - Uy) / np.absolute(Cooperate_degree[x][t] - Cooperate_degree[y][t]))))
                    if 0 <= random.uniform(0, 1) <= ran:
                        Cooperate_degree[x].append(Cooperate_degree[y][t])
                        Strategy[x].append(Strategy[y][t])
                    else:
                        Strategy[x].append(Strategy[x][t])
                        Cooperate_degree[x].append(Cooperate_degree[x][t])
                elif Type[x] == True:   # x is a conformist
                    s_temp = Strategy[x][t]
                    kh = len(x_nei) / 2
                    Nx = 0
                    for nei in x_nei:
                        if Strategy[nei][t] == s_temp:
                            Nx += 1
                    if s_temp == False:  # x is a cooperator
                        memory = sum(Strategy[x][-T:]) / len(Strategy[x][-T:])
                    else:   # x is a defector
                        memory = (len(Strategy[x][-T:]) - sum(Strategy[x][-T:])) / len(Strategy[x][-T:])
                    ran = c * memory + (1 - c) * (1 / (1 + np.exp((Nx - kh) / np.absolute(Cooperate_degree[x][t] - Cooperate_degree[y][t]))))
                    if 0 <= random.uniform(0, 1) <= ran:  # the strategy changes
                        Strategy[x].append(not Strategy[x][t])
                        Cooperate_degree[x].append(1 - Cooperate_degree[x][t])
                    else:
                        Strategy[x].append(Strategy[x][t])
                        Cooperate_degree[x].append(Cooperate_degree[x][t])
            f_c.append(fun_f(Strategy))
        f = np.mean(f_c[-500:])
        result['c={:.1f},r={:.1f},n={:.0f}'.format(c, r, n)] = f

json_str = json.dumps(result)
with open('./saves/n_f_RE.json', 'w') as json_file:
    json_file.write(json_str)