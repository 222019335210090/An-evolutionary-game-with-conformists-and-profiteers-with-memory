import networkx as nx
import numpy as np
import random
import warnings
import json

warnings.filterwarnings('ignore')

n = 1024

G = nx.watts_strogatz_graph(n, 4, 0.15)
ETime = 10000  # Evolutionary game steps
game = 'SG'
T = 5   # memory length
clist = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
rlist = [0.4, 0.5, 0.6, 0.7, 0.8]
avg = 10

fun_s = lambda x: random.uniform(0, 1) > x   # Get the strategy of the node according to s (False for cooperation, True for defection)
fun_f = lambda x: (len(x) - sum(list(map(lambda x: x[-1], list(x.values()))))) / len(x)   # Calculate the fc based on the dictionary of strategy

result = {}
for r in rlist:
    for c in clist:
        f_c_ = 0
        for average in range(avg):
            if game == "SG":
                pom = [[1, 1 - r], [1 + r, 0]]

            Strategy = {}
            Type = []
            f_c = []
            Cooperate_degree = {}

            for i in G.nodes:
                Type.append(0 <= random.uniform(0,1) < 0.5)     # False for profiteer, True for conformist
                Cooperate_degree[i] = [random.uniform(0,1)]
                Strategy[i] = [fun_s(Cooperate_degree[i][-1])]
            f_c.append(fun_f(Strategy))
            # iteration
            for t in range(ETime):
                for x in range(0, n):
                    print("\rr={:.1f},c={:.1f},t={:.0f},f_c={:.3f}".format(r, c, t, f_c[t]),end='')
                    x_nei = list(G.neighbors(x))
                    Ux = 0
                    for i in x_nei:
                        if Strategy[x][t] == Strategy[i][t] == False:  # C-C
                            Ux += Cooperate_degree[x][t] * Cooperate_degree[i][t] * pom[Strategy[x][t]][Strategy[i][t]]
                        elif (Strategy[x][t] == True) and (Strategy[i][t] == False):  # D-C
                            Ux += (1 - Cooperate_degree[x][t]) * Cooperate_degree[i][t] * pom[Strategy[x][t]][Strategy[i][t]]
                        else:
                            Ux += pom[Strategy[x][t]][Strategy[i][t]]

                    y = random.choice(x_nei)  # randomly choose a neighbor
                    y_nei = list(G.neighbors(y))
                    Uy = 0
                    for i in y_nei:
                        if Strategy[y][t] == Strategy[i][t] == False:  # C-C
                            Uy += Cooperate_degree[y][t] * Cooperate_degree[i][t] * pom[Strategy[y][t]][Strategy[i][t]]
                        elif (Strategy[y][t] == True) and (Strategy[i][t] == False):  # D-C
                            Uy += (1 - Cooperate_degree[y][t]) * Cooperate_degree[i][t] * pom[Strategy[y][t]][Strategy[i][t]]
                        else:
                            Uy += pom[Strategy[y][t]][Strategy[i][t]]

                    if Type[x] == False:  #  x is a profiteer
                        s_change = Strategy[y][t]
                        if s_change == False:   # the target is a cooperator
                            memory = (len(Strategy[x][-T:]) - sum(Strategy[x][-T:])) / len(Strategy[x][-T:])
                        else:   # the target is a defector
                            memory = sum(Strategy[x][-T:]) / len(Strategy[x][-T:])
                        ran = c * memory + (1 - c) * (1/(1 + np.exp((Ux - Uy)/np.absolute(Cooperate_degree[x][t]-Cooperate_degree[y][t]))))
                        if 0 <= random.uniform(0, 1) <= ran:
                            Cooperate_degree[x].append(Cooperate_degree[y][t])
                            Strategy[x].append(Strategy[y][t])
                        else:
                            Cooperate_degree[x].append(Cooperate_degree[x][t])
                            Strategy[x].append(Strategy[x][t])

                    elif Type[x] == True:  # x is a conformist
                        s_temp = Strategy[x][t]
                        kh = len(x_nei) / 2
                        Nx = 0
                        for nei in x_nei:
                            if Strategy[nei][t] == s_temp:
                                Nx += 1
                        if s_temp == False:    # x is a cooperator
                            memory = sum(Strategy[x][-T:]) / len(Strategy[x][-T:])
                        else:  # x is a defector
                            memory = (len(Strategy[x][-T:]) - sum(Strategy[x][-T:])) / len(Strategy[x][-T:])
                        ran = c * memory + (1 - c)*(1/(1+np.exp((Nx - kh)/np.absolute(Cooperate_degree[x][t]-Cooperate_degree[y][t]))))
                        if 0 <= random.uniform(0, 1) <= ran:  # the strategy changes
                            Strategy[x].append(not Strategy[x][t])
                            Cooperate_degree[x].append(1 - Cooperate_degree[x][t])
                        else:
                            Strategy[x].append(Strategy[x][t])
                            Cooperate_degree[x].append(Cooperate_degree[x][t])
                f_c.append(fun_f(Strategy))
            f_c_ += np.mean(f_c[-1000:])
        result["{:.2f}, {:.2f}".format(c, r)] = f_c_ / avg

json_str = json.dumps(result)
with open('./saves/c_f(r)_new_WS.json', 'w') as json_file:
    json_file.write(json_str)